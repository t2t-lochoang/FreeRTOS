#ifndef	__BOARD_INI_H__
#define __BOARD_INI_H__
#include "stm32f10x_rcc.h"
#include "stm32f10x_flash.h"
void Board_Init(void);
#endif	// __MINISTM32_H__
