#include "led.h"

void LED_Configuration(void)
{
	RCC_APB2PeriphClockCmd(LEDPORTCLK|LEDPORTCLK_1,ENABLE);	//ENABLE CLOCK cho GPIOC va GPIOD
	GPIO_InitTypeDef GPIO_InitStructure;			
	
  GPIO_InitStructure.GPIO_Pin = LED1|LED2;	
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;				//Output, tro keo
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				//Clock GPIO 50Mhz
  GPIO_Init(LEDPORT, &GPIO_InitStructure);								//Cai dat GPIOC
	
	GPIO_InitStructure.GPIO_Pin = LED3|LED4;	
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;				//Output, tro keo
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				//Clock GPIO 50Mhz
  GPIO_Init(LEDPORT_1, &GPIO_InitStructure);							//Cai dat GPIOC
} 


