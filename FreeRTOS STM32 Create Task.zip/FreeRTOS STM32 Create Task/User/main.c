#include "mytask.h"
#include "Board_ini.h"
int main(void)
{
	Board_Init();                //Config Frequency for chip
	LED_Configuration();         //Config LED PIN
	 
  xTaskCreate(vTaskLed1,( const char * ) "Task LED 1",configMINIMAL_STACK_SIZE,NULL,mainFLASH_TASK_PRIORITY,( xTaskHandle * ) NULL);
	xTaskCreate(vTaskLed2,( const char * ) "Task LED 2",configMINIMAL_STACK_SIZE,NULL,mainFLASH_TASK_PRIORITY,( xTaskHandle * ) NULL);
//	xTaskCreate(vTaskLed3,( const char * ) "Task LED 3",configMINIMAL_STACK_SIZE,NULL,mainFLASH_TASK_PRIORITY,( xTaskHandle * ) NULL);
//	xTaskCreate(vTaskLed4,( const char * ) "Task LED 4",configMINIMAL_STACK_SIZE,NULL,mainFLASH_TASK_PRIORITY,( xTaskHandle * ) NULL);
	
	vTaskStartScheduler();	
}
