#ifndef _BUTTON_H_
#include "stm32f10x_gpio.h"
#include "stm32f10x_rcc.h"
#define _BUTTON_H_
//Define for BUTTON
#define BUTTON1 				GPIO_Pin_2			
#define BUTTON2 				GPIO_Pin_3
#define BUTTON3 				GPIO_Pin_4
#define BUTTON4 				GPIO_Pin_5

#define BUTTONPORT			GPIOE
#define BUTTONPORTCLOCK RCC_APB2Periph_GPIOE
void ButtonInit(void);
#endif

