#include "stm32f10x.h"
#include <stdlib.h>
#include "Board_ini.h"

void Board_Init(void)
{

//	  SystemInit();
	ErrorStatus HSEStartUpStatus;
	/* SYSCLK, HCLK, PCLK2 and PCLK1 configuration -----------------------------*/   
	/* RCC system reset(for debug purpose) */
	RCC_DeInit();
	/* Enable HSE */
	RCC_HSEConfig(RCC_HSE_ON);
	/* Wait till HSE is ready */
	HSEStartUpStatus = RCC_WaitForHSEStartUp();
	if (HSEStartUpStatus == SUCCESS)
	{
		/* Enable Prefetch Buffer */
		FLASH_PrefetchBufferCmd(FLASH_PrefetchBuffer_Enable);

		/* Flash 2 wait state */
		FLASH_SetLatency(FLASH_Latency_2);
 
		/* HCLK = SYSCLK */
		RCC_HCLKConfig(RCC_SYSCLK_Div1); 
  
 		/* PCLK2 = HCLK */
		RCC_PCLK2Config(RCC_HCLK_Div1); 

		/* PCLK1 = HCLK/2 */
		RCC_PCLK1Config(RCC_HCLK_Div2);

		/* PLLCLK = 8MHz * 9 = 72 MHz */
    	RCC_PLLConfig(RCC_PLLSource_HSE_Div1, RCC_PLLMul_9);

		/* Enable PLL */ 
		RCC_PLLCmd(ENABLE);

		/* Wait till PLL is ready */
		while (RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET)
		{
		}

		/* Select PLL as system clock source */
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);

		/* Wait till PLL is used as system clock source */
		while(RCC_GetSYSCLKSource() != 0x08)		{		}

	}else
	{ 
		RCC_DeInit();
		 /***************HSI CLOCK****************/
	//TURN ON HSI AND SET IT AS SYSCLK SRC
	//SETUP THE SYSTEM CLOCK AS BELOW
	//CLOCK SRC = 8MHZ HSI + PLL
	//SYSCLK = 64MHZ
	//HCLK = SYSCLK = 64MHZ
	//PCLK2 = HCLK = 64MHZ
	//PCLK1 = HCLK = 32MHZ

	//	//TURN ON HSI AND SET IT AS SYSCLK SRC
		RCC_HSICmd(ENABLE);
		while(RCC_GetFlagStatus(RCC_FLAG_HSIRDY) == RESET){};

		//SET HSI AS SYSCLK SRC. CONFIGURE HCLK, PCLK1 & PCLK2
		RCC_SYSCLKConfig(RCC_SYSCLKSource_HSI);
		RCC_HCLKConfig(RCC_SYSCLK_Div1);
		RCC_PCLK1Config(RCC_HCLK_Div1);
		RCC_PCLK2Config(RCC_HCLK_Div1);
		//SET THE FLASH LATENCY AS PER OUR CLOCK
		//FASTER THE CLOCK, MORE LATENCY THE FLASH NEEDS
		//000 Zero wait state, if 0  MHz < SYSCLK <= 24 MHz
		//001 One wait state, if  24 MHz < SYSCLK <= 48 MHz
		//010 Two wait states, if 48 MHz < SYSCLK <= 72 MHz */
		FLASH_SetLatency(FLASH_Latency_2);

		//DISABLE PLL
		RCC_PLLCmd(DISABLE);
		//CHANGE PLL SRC AND MULTIPLIER
		RCC_PLLConfig(RCC_PLLSource_HSI_Div2, RCC_PLLMul_16);
		//ENABLE PLL
		//WAIT FOR IT TO BE READY
		//SET SYSCLK SRC AS PLLCLK
		RCC_PLLCmd(ENABLE);
		while(RCC_GetFlagStatus(RCC_FLAG_PLLRDY) == RESET){};
		RCC_SYSCLKConfig(RCC_SYSCLKSource_PLLCLK);
		FLASH_SetLatency(FLASH_Latency_2);
		//SET HCLK = SYSCLK = 64MHZ
		RCC_HCLKConfig(RCC_SYSCLK_Div1);
		//SET PCLK2 = HCLK = 64MHZ
		RCC_PCLK2Config(RCC_HCLK_Div1);

		//SET PCLK1 = HCLK/2 = 32MHZ
		RCC_PCLK1Config(RCC_HCLK_Div2);
	}
	// DMA1 for ADC, RTC and PWR
	  RCC_AHBPeriphClockCmd(RCC_AHBPeriph_DMA1, ENABLE);
	/* Enable GPIOA, GPIOB, GPIOC, GPIOD, GPIOE and AFIO clocks */
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO, ENABLE );
 
}
