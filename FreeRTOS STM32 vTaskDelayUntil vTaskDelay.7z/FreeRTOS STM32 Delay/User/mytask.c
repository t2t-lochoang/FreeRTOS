#include "mytask.h"
void vTaskLed1(void *pvParameters)
{
	char led_val = 0;
	unsigned int Frequency = 1000;         //1s
	TickType_t xLastWakeTime;
	xLastWakeTime = xTaskGetTickCount();
	while(1)
	{
		led_val = 1 - led_val;
		GPIO_WriteBit(LEDPORT,LED1,led_val ? Bit_SET : Bit_RESET);
//		delay_ms(1000);
		vTaskDelayUntil(&xLastWakeTime, Frequency);
	}
}
void vTaskLed2(void *pvParameters)
{
	char led_val = 0;
	unsigned int Frequency = 1000;         //1s
	while(1)
	{
		led_val = 1 - led_val;
		GPIO_WriteBit(LEDPORT,LED2,led_val ? Bit_SET : Bit_RESET);
//		delay_ms(1000);
		vTaskDelay(Frequency);
	}
}
