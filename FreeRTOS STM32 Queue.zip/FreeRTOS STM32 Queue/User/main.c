#include "mytask.h"
#include "Board_ini.h"
int main(void)
{
	Board_Init();                //Config Frequency for chip
	ButtonInit();
	LED_Configuration();         //Config LED PIN
	Create_Queue();              //Create Queue
  xTaskCreate(vTaskControlLED,( const char * ) "Task LED",configMINIMAL_STACK_SIZE,NULL,mainFLASH_TASK_PRIORITY,( xTaskHandle * ) NULL);
	xTaskCreate(vButtonCheck,( const char * ) "Task Button ",configMINIMAL_STACK_SIZE,NULL,mainFLASH_TASK_PRIORITY,( xTaskHandle * ) NULL);
	vTaskStartScheduler();	
}
