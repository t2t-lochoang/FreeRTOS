#include "button.h"
void ButtonInit(void)
{
	RCC_APB2PeriphClockCmd(BUTTONPORTCLOCK ,ENABLE);	     //ENABLE CLOCK 
	GPIO_InitTypeDef GPIO_InitStructure;			
	
  GPIO_InitStructure.GPIO_Pin = BUTTON1|BUTTON2|BUTTON3|BUTTON4;	
  GPIO_InitStructure.GPIO_Mode =   GPIO_Mode_IN_FLOATING;				//Input, tro keo
  GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;				//Clock GPIO 50Mhz
  GPIO_Init(BUTTONPORT, &GPIO_InitStructure);							//Cai dat GPIOC
}
